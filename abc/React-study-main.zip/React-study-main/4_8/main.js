const myName = "hyesung"
const email = "2014cococo@gmail.com"
const hello = `hello ${myName}??`

console.log(hello)

const number = 10;
const number2 = 10.55;

// const checked = True;
// const isShow = False;

let undef;
const obj = {abc:123};
console.log(undef);
console.log(obj.abc);
console.log(obj.xyz);

let name = null;
console.log(name);
name = "hihi"
console.log(name);

const user = {
    userName : "hs",
    age : 18,
    isValid : true 
};

console.log(user.userName);
console.log(user.age);
console.log(user.isValid);

const fruits = ['Apple', 'Banana', 'Cherry'];
console.log(fruits[0])

function abc() {
    var aaa = "A";
    console.log(aaa);
}
let a = 12;
console.log(a);
a = 999;
console.log(a);