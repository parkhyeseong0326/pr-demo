// let time = prompt("시간을 입력하세요");

// if (time <= 12) {
//     alert("오전");
// }
// else {
//     alert("오후");
// }




let n = prompt("달러 입력");
alert(1300 * n);

let A = "aaa";
console.log(typeof(A));


let score = Number(prompt("학점을 입력하세요","학점"));
if (score == 4.5) {
    
}