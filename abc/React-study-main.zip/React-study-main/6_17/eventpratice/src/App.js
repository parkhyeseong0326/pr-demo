import logo from './logo.svg';
import './App.css';
import Eventpratice from './eventpratice';

function App() {
  return (
    <Eventpratice/>
  );
}

export default App;
