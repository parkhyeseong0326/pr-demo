const MyComponent = () => {
    return <div>새로운 컴포넌트</div>
}
export default MyComponent