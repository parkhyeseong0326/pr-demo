let data = [
    {
        id : 0,
        title : "white and black",
        content : "from France",
        price : 120000
    },
    {
        id : 1,
        title : "red wine",
        content : "from seoul",
        price : 110000
    },
    {
        id : 2,
        title : "Grey lordan",
        content : "from United States",
        price : 130000
    }
]

export default data;