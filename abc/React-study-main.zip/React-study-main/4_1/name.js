const elemets = document.querySelectorAll('div')
elemets.forEach(element => {
    console.log(element.dataset.fruitName)
})