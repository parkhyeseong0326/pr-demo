let age = 20;
let name = 'hye'
export default {age,name};