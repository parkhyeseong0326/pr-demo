export default function product() {
    return (
        <div>
            <div className="food">상품 1</div>
        </div>
    )
}