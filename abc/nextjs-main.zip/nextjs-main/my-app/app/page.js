export default function Home() {
  let name = 'hye sung'
  return (
    <div>
      <h4 className="title" style={{color:'red'}}>충주상고</h4>
      <p className="title-sub">by {name}</p>
    </div>
  );
}
